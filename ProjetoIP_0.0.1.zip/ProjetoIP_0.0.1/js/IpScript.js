//alert("Entrei");

//Gerando IP
var Ip;

document.getElementById('botao1').onclick = function () {
    
    
    var numb=[0,0,0,0,0];

    for(var i=0;i<4;i++){
        numb[i]=RandomIp();
        if((numb[0]>191)||(numb[0]==10)||(numb[0]==0)||((numb[0]>14)&&(numb[0]<39))||((numb[0]>126)&&(numb[0]<129))){
            numb[0]=RandomIp();
        }
    }


    function RandomIp (){
        var val=[5, 50, 200];
        var a;
        var b=0;
        
        for(var i =0;i<3;i++){
            a= (Math.floor((Math.random() * val[i])));
            b=a+b;
        }
        return b;
    }
    
    Ip = "http://"+(numb[1]+"."+numb[2]+"."+numb[3]+"."+numb[4]);
    document.getElementById('usr').value = Ip;
};

document.getElementById('botao2').onclick = function () {

    
    
    function checkOnline(Ip) {            
            
            document.getElementById('detetive').src = "img/load.gif"; 
            var scriptElem = document.createElement('script');
            scriptElem.type = 'text/javascript';
            scriptElem.onerror = function(){
                alert("Page Not Found");
                document.location.reload(true);
            };
            scriptElem.onload = function(){
                alert("Page Online");
                window.open(Ip);
            };
            scriptElem.src = Ip;
            document.getElementsByTagName("body")[0].appendChild(scriptElem);
    };
    
    checkOnline(Ip);
};
