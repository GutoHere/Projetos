

document.getElementById('botao3').onclick = function () {
    
    document.getElementById('botao3').disabled = "disabled";
    var flag = 0;
    
    var endereco = document.getElementById('campo').value ;
    
    if(endereco.substring(0, 7)!="http://"){
        endereco="http://" + endereco;
    }

    else{
        //endereco=endereco.substring(7);
    }

    function checkOnline(url) {
        try {
            
            var scriptElem = document.createElement('script');
            scriptElem.type = 'text/javascript';
            scriptElem.onerror = function(){
                document.getElementById('imagem').src = 'img/offline.png';
                alert("Page Not Found");
                //document.location.reload(true);
            };
            scriptElem.onload = function(){
                document.getElementById('imagem').src = 'img/online.png';
                alert("Page Online");
                //document.location.reload(true);
                flag = 1;
            };
            scriptElem.src = url;
            document.getElementsByTagName("body")[0].appendChild(scriptElem);
        } catch(err) {
            error(err);
        }
    };
    
    checkOnline(endereco);
};



document.getElementById('botao4').onclick = function () {
    
    document.location.reload(true);
    
    
};